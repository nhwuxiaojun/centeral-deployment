/*------------------------------------------------------------------------------
 * PACKAGE: com.freeware.gridtag
 * FILE   : GridPager.java
 * CREATED: Jul 24, 2004
 * AUTHOR : Prasad P. Khandekar
 *------------------------------------------------------------------------------
 * Change Log:
 *-----------------------------------------------------------------------------*/
package com.freeware.gridtag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

/**
 * This class represents the grid pager.
 * @author Prasad P. Khandekar
 * @version 1.0
 * @since 1.0
 */
public final class GridPager extends TagSupport
{
	private static final long serialVersionUID = 6100864455702214641L;

	private String mstrImgFirst;
    private String mstrImgPrevious;
    private String mstrImgNext;
    private String mstrImgLast;

    public GridPager()
    {
        super();
        this.mstrImgFirst = "images/First.gif";
        this.mstrImgPrevious = "images/Previous.gif";
        this.mstrImgNext = "images/Nextt.gif";
        this.mstrImgLast = "images/Last.gif";
    }

/*------------------------------------------------------------------------------
 * Getters
 *----------------------------------------------------------------------------*/
    public String getImgFirst()
    {
        return this.mstrImgFirst;
    }

    public String getImgPrevious()
    {
        return this.mstrImgPrevious;
    }

    public String getImgNext()
    {
        return this.mstrImgNext;
    }

    public String getImgLast()
    {
        return this.mstrImgLast;
    }

/*------------------------------------------------------------------------------
 * Setters
 *----------------------------------------------------------------------------*/
    public void setImgFirst(String pstrImgFirst)
    {
        this.mstrImgFirst = pstrImgFirst;
    }

    public void setImgPrevious(String pstrImgPreviosu)
    {
        this.mstrImgPrevious = pstrImgPreviosu;
    }

    public void setImgNext(String pstrImgNext)
    {
        this.mstrImgNext = pstrImgNext;
    }

    public void setImgLast(String pstrImgLast)
    {
        this.mstrImgLast = pstrImgLast;
    }

/*------------------------------------------------------------------------------
 * Overridden methods
 * @see javax.servlet.jsp.tagext.Tag
 *----------------------------------------------------------------------------*/
    /* (non-Javadoc)
     * @see javax.servlet.jsp.tagext.Tag#doEndTag()
     */
    public int doEndTag() throws JspException
    {
        DBGrid objTmp = null;

        try
        {
            objTmp = (DBGrid) getParent();
            objTmp.setPager(getCopy());
        }
        catch (ClassCastException CCEx)
        {
            throw new JspException("Error: ImageColumn tag is not a child of DBGrid", CCEx);
        }
        finally
        {
            if (objTmp != null) objTmp = null;
        }
        return EVAL_PAGE;
    }

    /* (non-Javadoc)
     * @see javax.servlet.jsp.tagext.Tag#doStartTag()
     */
    public int doStartTag() throws JspException
    {
        if (!(this.getParent() instanceof DBGrid))
            throw new JspException("Error: Column tag needs to be a child of DBGrid!");

        // This tag does not have body contents.
        return SKIP_BODY;
    }

/*------------------------------------------------------------------------------
 * Methods
 *----------------------------------------------------------------------------*/
    public void renderPager(int pintCurrPage, int pintTotRec, int pintPageSize) throws JspException
    {
        int          intPages = 0;
        StringBuffer objBuf = null;

        try
        {
            if ((pintTotRec % pintPageSize) == 0)
                intPages = pintTotRec / pintPageSize;
            else
                intPages = (pintTotRec / pintPageSize) + 1;

	        objBuf = new StringBuffer();
	        objBuf.append("<table BORDER=0 CELLSPACING=0 CELLPADDING=0 ");
	        objBuf.append("WIDTH=\"100%\">\r\n");
	        objBuf.append("<tr CLASS=\"gridPager\">\r\n");
	        objBuf.append("<td ALIGN=\"left\" WIDTH=\"70%\">\r\n");
	        objBuf.append("<a HREF=\"javascript:doNavigate('F', " + intPages + 
	                        ")\">\r\n");
	        objBuf.append("<img SRC=\"" + this.mstrImgFirst + "\" BORDER=0></a>\r\n");
	        objBuf.append("<a HREF=\"javascript:doNavigate('P', " + intPages +
	                        ")\">\r\n");
	        objBuf.append("<img SRC=\"" + this.mstrImgPrevious + "\" BORDER=0></a>\r\n");
	        objBuf.append("<a HREF=\"javascript:doNavigate('N', " + intPages +
	                        ")\">\r\n");
	        objBuf.append("<img SRC=\"" + this.mstrImgNext + "\" BORDER=0></a>\r\n");
	        objBuf.append("<a HREF=\"javascript:doNavigate('L', " + intPages +
	                        ")\">\r\n");
	        objBuf.append("<img SRC=\"" + this.mstrImgLast + "\" BORDER=0></a>\r\n");
	        objBuf.append("</td>\r\n");
	        objBuf.append("<td ALIGN=\"right\" WIDTH=\"30%\" ");
	        objBuf.append("CLASS=\"gridPageOfPage\">\r\n");
	        objBuf.append("Page " + pintCurrPage + " of " + intPages);
	        objBuf.append("</td>\r\n");
	        objBuf.append("</tr>\r\n");
	        objBuf.append("</table>\r\n");
	        this.pageContext.getOut().println(objBuf.toString());
        }
        catch (IOException IoEx)
        {
            throw new JspException("Error: While drawing grid pager!", IoEx);
        }
        finally
        {
            if (objBuf != null) objBuf = null;
        }
    }

/*------------------------------------------------------------------------------
 * Helpers
 *----------------------------------------------------------------------------*/
    private GridPager getCopy()
    {
        GridPager objRet = null;

        objRet = new GridPager();
        objRet.setId(this.getId());
        objRet.setPageContext(this.pageContext);
        objRet.setParent(this.getParent());
        objRet.setImgFirst(this.mstrImgFirst);
        objRet.setImgPrevious(this.mstrImgPrevious);
        objRet.setImgNext(this.mstrImgNext);
        objRet.setImgLast(this.mstrImgLast);
        return objRet;
    }
}
